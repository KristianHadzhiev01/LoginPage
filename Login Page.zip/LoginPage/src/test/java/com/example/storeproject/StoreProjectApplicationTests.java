package com.example.storeproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
