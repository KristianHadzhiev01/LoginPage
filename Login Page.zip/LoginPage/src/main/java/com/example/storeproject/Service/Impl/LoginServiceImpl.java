package com.example.storeproject.Service.Impl;

import com.example.storeproject.Models.Dtos.LoginUserDto;
import com.example.storeproject.Models.Entities.User;
import com.example.storeproject.Repositories.UserRepository;

import com.example.storeproject.Service.LoginService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginServiceImpl implements LoginService {
    private final UserRepository userRepository;

    public LoginServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    @Override
    public boolean loginUser(LoginUserDto user) {
        Optional<User> optionalUser = this.userRepository.findUserByUsernameAndPassword(user.getUsername(), user.getPassword());
        return optionalUser.isPresent();
    }
}
