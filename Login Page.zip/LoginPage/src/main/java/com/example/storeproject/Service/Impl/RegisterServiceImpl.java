package com.example.storeproject.Service.Impl;

import com.example.storeproject.Models.Dtos.RegisterUserDto;
import com.example.storeproject.Models.Entities.User;
import com.example.storeproject.Repositories.UserRepository;
import com.example.storeproject.Service.RegisterService;
import com.example.storeproject.Utils.ValidationUtilImpl;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RegisterServiceImpl implements RegisterService {
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final ValidationUtilImpl validationUtil;

    public RegisterServiceImpl(ModelMapper modelMapper, UserRepository userRepository, ValidationUtilImpl validationUtil) {
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.validationUtil = validationUtil;
    }

    @Override
    public void registerUser(RegisterUserDto user) {
        Optional<User> optionalUser = this.userRepository.findUserByUsernameAndPassword(user.getUsername(), user.getPassword());
        if (validationUtil.isValid(user) && optionalUser.isEmpty()) {
            User currentUser = modelMapper.map(user, User.class);
            userRepository.save(currentUser);
        } else {
            throw new NullPointerException("User cannot be null");
        }
    }
}
