package com.example.storeproject.Utils;

public interface ValidationUtil {
    <E> boolean isValid(E entity);
}