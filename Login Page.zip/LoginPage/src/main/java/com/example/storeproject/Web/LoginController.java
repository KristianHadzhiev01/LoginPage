package com.example.storeproject.Web;

import com.example.storeproject.Models.Dtos.LoginUserDto;
import com.example.storeproject.Service.Impl.LoginServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    private final LoginServiceImpl loginService;

    public LoginController(LoginServiceImpl loginService) {
        this.loginService = loginService;
    }

    @GetMapping("/login")
    public String login(){
     return "loginPage";
    }

    @PostMapping("/login")
    public String userLogin(@ModelAttribute LoginUserDto user){

            if(loginService.loginUser(user)){
                return "loggedInUser";
    }
            return "userNotExist";
}
    @RequestMapping(value = "/login")
    public String saveUser(LoginUserDto user){
        return "loggedInUser";
    }

    }