package com.example.storeproject.Models.Entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Users")
public class User extends BaseEntity{
    @Column(nullable = false, unique = true)
    @Size(min = 3)
    private String username;
    @Column(nullable = false)
    @Size(min = 4)
    private String password;
    @Column(name = "email_address",unique = true,nullable = false)
    @Email
    private String email;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}