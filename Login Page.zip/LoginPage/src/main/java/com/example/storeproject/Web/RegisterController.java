package com.example.storeproject.Web;

import com.example.storeproject.Models.Dtos.RegisterUserDto;
import com.example.storeproject.Service.Impl.RegisterServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegisterController {
private final RegisterServiceImpl registerService;

    public RegisterController(RegisterServiceImpl registerService) {
        this.registerService = registerService;
    }

    @GetMapping("/register")
    public String register(){
         return "RegisterPage";
     }

     @PostMapping("/register")
    public String userRegistration(@ModelAttribute RegisterUserDto user){
         try {
             registerService.registerUser(user);
         }catch (NullPointerException e){
             return "UserExist";
         }
         return "userRegistered";
     }
}
