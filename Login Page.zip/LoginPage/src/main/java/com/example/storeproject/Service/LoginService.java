package com.example.storeproject.Service;

import com.example.storeproject.Models.Dtos.LoginUserDto;

public interface LoginService {
    public boolean loginUser(LoginUserDto user);
}
