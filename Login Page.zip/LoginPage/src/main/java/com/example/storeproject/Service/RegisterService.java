package com.example.storeproject.Service;

import com.example.storeproject.Models.Dtos.RegisterUserDto;

public interface RegisterService {
    public void registerUser(RegisterUserDto user);
}
